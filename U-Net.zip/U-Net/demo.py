#
# demo.py
#
import argparse
import os
import numpy as np
import time
import cv2

from modeling.unet import *
from dataloaders import custom_transforms as tr
from PIL import Image
from torchvision import transforms
from dataloaders.utils import *
from torchvision.utils import make_grid, save_image
from utils.metrics import Evaluator
from tkinter import filedialog
def main():
    parser = argparse.ArgumentParser(description="PyTorch Unet Test")
    # parser.add_argument('--in-path', type=str, default='B:\\code\\Gr-segmentation\\data\\Test\\label\\F5\\Image',  help='image to test')
    parser.add_argument('--in-path', type=str, default=r'A:\B_diskexpand\Code\GrMflakes\data\SEM\Testset\Modelresult\image\largescale',  help='image to test')
    #filedialog.askdirectory(title="请选择测试图像所在的文件夹")
    # parser.add_argument('--ckpt', type=str, default='A:\\B_diskexpand\\Code\\U-Net-pytorch-SLG\\run\\pascal\\Unet\\batch6_500epoch\\checkpoint0.7949.pth.tar',
    parser.add_argument('--ckpt', type=str, default=r'A:\B_diskexpand\Code\U-Net-pytorch-SLG\run\pascal\Unet\finalusedexperiment\bestcheckpoint_ep932.pth.tar',
#'D:/HSQ/dataset_two-2/vocsft/pred-vocsft/20220804/model_best.pth.tar',  checkpoint.pth.tar
#'D:/HSQ/dataset_two-2/vocloop/pred-vocloop/20220802/model_best.pth.tar'
    # parser.add_argument('--ckpt', type=str, default = filedialog.askopenfilename(title="请选择模型文件：", filetypes=[("Image files", "*.pth.tar"), ("All files", "*.*")],              #'D:/HSQ/dataset_two-2/vocsft/pred-vocsft/20220804/model_best.pth.tar',  checkpoint.pth.tar              #'D:/HSQ/dataset_two-2/vocloop/pred-vocloop/20220802/model_best.pth.tar'
                        help='saved model')
    parser.add_argument('--no-cuda', action='store_true', default=False,
                        help='disables CUDA training')
    parser.add_argument('--gpu-ids', type=str, default='0',
                        help='use which gpu to train, must be a \
                        comma-separated list of integers only (default=0)')
    parser.add_argument('--dataset', type=str, default='pascal',
                        choices=['pascal', 'coco', 'cityscapes','invoice'],
                        help='dataset name (default: pascal)')
    parser.add_argument('--crop-size', type=int, default=512,
                        help='crop image size')
    parser.add_argument('--num_classes', type=int, default=2,        #改为2
                        help='crop image size')
    parser.add_argument('--sync-bn', type=bool, default=None,
                        help='whether to use sync bn (default: auto)')
    parser.add_argument('--freeze-bn', type=bool, default=False,
                        help='whether to freeze bn parameters (default: False)')

    args = parser.parse_args()
    args.cuda = not args.no_cuda and torch.cuda.is_available()
    if args.cuda:
        try:
            args.gpu_ids = [int(s) for s in args.gpu_ids.split(',')]
        except ValueError:
            raise ValueError('Argument --gpu_ids must be a comma-separated list of integers only')

    if args.sync_bn is None:
        if args.cuda and len(args.gpu_ids) > 1:
            args.sync_bn = True
        else:
            args.sync_bn = False
    model_s_time = time.time()
    model = Unet(n_channels=3, n_classes=2)             #务必改为正确的类别数

    ckpt = torch.load(args.ckpt, map_location='cpu')
    model.load_state_dict(ckpt['state_dict'], strict=False)
    model = model.cuda()
    model_u_time = time.time()
    model_load_time = model_u_time-model_s_time
    print("model load time is {}".format(model_load_time))
    composed_transforms = transforms.Compose([
        tr.Normalize(mean=(0.485, 0.456, 0.406), std=(0.229, 0.224, 0.225)),
        tr.ToTensor()])
    for name in os.listdir(args.in_path):
        s_time = time.time()
        image = Image.open(args.in_path+"/"+name).convert('RGB')

        target = Image.open(args.in_path+"/"+name).convert('L')
        sample = {'image': image, 'label': target}
        tensor_in = composed_transforms(sample)['image'].unsqueeze(0)
        tensor_out = composed_transforms(sample)['label'].unsqueeze(0)
        model.eval()
        evaluator = Evaluator(2)                        #Evaluator(nclass)
        evaluator.reset()
        if args.cuda:
            tensor_in = tensor_in.cuda()
        output = model(tensor_in)
        print("output", output)
        pred = output.data.cpu().numpy()
        target = tensor_out
        target = target.cpu().numpy()
        pred = np.argmax(pred, axis=1)
        # Add batch sample into evaluator
        evaluator.add_batch(target, pred)
        Acc = evaluator.Pixel_Accuracy()
        print("Accuracy is : {}.".format(Acc))
        Acc_class = evaluator.Pixel_Accuracy_Class()
        print("Class Average Accuracy is : {}.".format(Acc_class))
        mIoU = evaluator.Mean_Intersection_over_Union()
        print("Mean Intersection over Union is : {}.".format(mIoU))
        FWIoU = evaluator.Frequency_Weighted_Intersection_over_Union()
        print("Frequency Weighted Intersection over Union is :{}.".format(FWIoU))
        mDice = evaluator.Dice_coefficient()
        print("Mean Dice coefficient is :{}.".format(mDice))
        grid_image = make_grid(decode_seg_map_sequence(torch.max(output[:3], 1)[1].detach().cpu().numpy()), 3, normalize=False, value_range=(0, 9))
        # save_image(grid_image, 'B:\\code\\U-Net-pytorch-SLG\\curve'+"/"+"{}.png".format(name[0:-4]))              #D:/HSQ/dataset_two-2/voc2012/pred-voc2012/20220730
        # outputpath = 'B:\\code\\Gr-segmentation\\data\\Test\\label\\F5' + "/" + "{}.png".format(name[0:-4])
        outputpath = r'A:\B_diskexpand\Code\GrMflakes\data\SEM\Testset\UNetepo932' + "/" + "{}.png".format(name[0:-4])
        save_image(grid_image, outputpath)         #save_image(grid_image, 'D:/HSQ/dataset_two-2/vocsft/vocsft3/JPEGImages/predict'+"/"+"{}.png".format(name[0:-4]))
        u_time = time.time()
        img_time = u_time-s_time
        print("image:{} time: {} ".format(name, img_time))
        print("输出路径为： ", outputpath)

    print("image save in in_path.")
if __name__ == "__main__":
   # 获取当前时间
   start_time = time.time()
   main()

   # 获取当前时间
   end_time = time.time()
   # 计算并输出代码执行时间
   execution_time = end_time - start_time
   print(f"总测试时间: {execution_time} seconds")



#configuration parameters输入--in-path=D:/HSQ/dataset_two-2/voc2012/test
#--in-path=A:/figure/2

