#https://blog.csdn.net/brf_UCAS/article/details/112383722.  Pytorch下实现Unet对自己多类别数据集的语义分割



import argparse
import glob
import os
import time
import numpy as np
from tqdm import tqdm
from mypath import Path
from dataloaders import make_data_loader
from modeling.unet import *
from utils.loss import SegmentationLosses
from utils.calculate_weights import calculate_weigths_labels
from utils.lr_scheduler import LR_Scheduler
from utils.saver import Saver
from utils.summaries import TensorboardSummary
from utils.metrics import Evaluator
from pytorchtools import EarlyStopping
from visualdl import LogWriter
import torch.onnx
import pandas as pd
import warnings

warnings.filterwarnings('ignore')
###https://zhuanlan.zhihu.com/p/590817058.
torch.backends.cudnn.enable =True        #20230522修改
################################################

#将MedSAM-main中的mask用于本项目之前，需要在Dataset-prehandle项目中运行UNet SegmentationClass depart 24RGB channel to 8R.py，将24位白色mask转为8位伪彩色mask。

class Trainer(object):
    def __init__(self, args):
        self.args = args
        # Define Saver
        self.saver = Saver(args)
        self.saver.save_experiment_config()
        # Define Tensorboard Summary
        self.summary = TensorboardSummary(self.saver.experiment_dir)
        self.writer = self.summary.create_summary()

        # Define Dataloader
        kwargs = {'num_workers': args.workers, 'pin_memory': True}
        self.train_loader, self.val_loader, self.test_loader, self.nclass = make_data_loader(args, **kwargs)

        print("\n训练集路径：", self.train_loader.dataset._base_dir)
        print("训练集张数：", len(self.train_loader.dataset))
        print("验证集路径：", self.val_loader.dataset._base_dir)
        print("验证集张数：", len(self.val_loader.dataset))

        # Define network
        model = Unet(n_channels=3, n_classes=args.num_classes)             #如果加载预训练的模型，则例如model = models.resnet18(pretrained=True)
        total_params = sum(p.numel() for p in model.parameters())
        trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
        self.param_info = {'总参数量': total_params, '可训练参数量': trainable_params}
        print("UNet 总参数量：", total_params, " 可训练参数量：", trainable_params)
        train_params = [{'params': model.parameters(), 'lr': args.lr}]

        # Define Optimizer
        optimizer = torch.optim.SGD(train_params, momentum=args.momentum,
                                    weight_decay=args.weight_decay, nesterov=args.nesterov)

        ##################################################################
        # Define Criterion
        # whether to use class balanced weights
        if args.use_balanced_weights:
            classes_weights_path = os.path.join(args.data_root or Path.db_root_dir(args.dataset), args.dataset + '_classes_weights.npy')
            if os.path.isfile(classes_weights_path):
                weight = np.load(classes_weights_path)
            else:
                weight = calculate_weigths_labels(args.dataset, self.train_loader, self.nclass, data_root=args.data_root)
            weight = torch.from_numpy(weight.astype(np.float16))
        else:
            weight = None
        self.criterion = SegmentationLosses(weight=weight, cuda=args.cuda).build_loss(mode=args.loss_type)
        self.model, self.optimizer = model, optimizer

        # Define Evaluator
        self.evaluator = Evaluator(self.nclass)
        # Define lr scheduler
        self.scheduler = LR_Scheduler(args.lr_scheduler, args.lr,
                                      args.epochs, len(self.train_loader))
        self.learningrate=self.scheduler.lr

        print("\n学习率变成：", self.learningrate)
        print("==================== 训练参数 ====================")
        for _k, _v in vars(self.args).items():
            print("{}: {}".format(_k, _v))
        print("===================================================")

        # Using cuda
        if args.cuda:
            self.model = torch.nn.DataParallel(self.model, device_ids=self.args.gpu_ids)
            self.model = self.model.cuda()
        self.max_peak_alloc = 0.0
        self.max_peak_reserved = 0.0
        if args.cuda:
            for d in self.args.gpu_ids:
                torch.cuda.reset_peak_memory_stats(d)
        self.train_start_time = time.time()
        self._last_epoch_time = None
        self.train_records = []
        self.val_records = []
        # Resuming checkpoint
        self.best_pred = 0.0

        if args.resume:
            if args.check is None:
                args.check = find_latest_checkpoint(args.run_dir, args.dataset, args.checkname)
            if args.check is not None and os.path.isfile(args.check):
                print("checkpoint文件保存路径：", args.check)
                checkpoint = torch.load(args.check)
                args.start_epoch = checkpoint['epoch']
                if args.cuda:
                    self.model.module.load_state_dict(checkpoint['state_dict'])
                else:
                    self.model.load_state_dict(checkpoint['state_dict'])
                if not args.ft:
                    self.optimizer.load_state_dict(checkpoint['optimizer'])
                self.best_pred = checkpoint['best_pred']
                print("=> loaded checkpoint '{}' (epoch {})"
                      .format(args.check, checkpoint['epoch']))
            else:
                print("未找到checkpoint，将从epoch 0开始新训练")
        else:
            print("resume=False，将从epoch 0开始重新训练")

        # Clear start epoch if fine-tuning
        if args.ft:
            args.start_epoch = 0                    #如果使用微调，则从0个epoch开始训练。

        self._write_record()

    def _write_record(self):
        trainable_layers = sum(1 for p in self.model.parameters() if p.requires_grad)
        lines = [
            '========== 训练记录 ==========',
            '数据集名称: ' + str(self.args.dataset),
            '训练数据路径: ' + str(self.train_loader.dataset._base_dir),
            '验证数据路径: ' + str(self.val_loader.dataset._base_dir),
            '任务名称: ' + str(self.args.checkname),
            '模型类型: ' + 'Unet(n_channels=3, n_classes={})'.format(self.args.num_classes),
            '预训练权重: ' + str(self.args.check or '无'),
            '设备: ' + (str(self.args.gpu_ids) if self.args.cuda else 'CPU'),
            '工作目录: ' + str(self.args.project_root),
            '训练轮数 (num_epochs): ' + str(self.args.epochs),
            '批次大小 (batch_size): ' + str(self.args.batch_size),
            '学习率 (lr): ' + str(self.args.lr),
            '权重衰减 (weight_decay): ' + str(self.args.weight_decay),
            '优化器: ' + 'SGD(momentum={}, nesterov={})'.format(self.args.momentum, self.args.nesterov),
            '损失函数及权重: ' + {'dicece_bce': 'DiceCELoss(1)+BCE(1)', 'dicece': 'DiceLoss(1)+CE(1)'}.get(
                str(self.args.loss_type), str(self.args.loss_type)) + ('(balanced)' if self.args.use_balanced_weights else ''),
            '学习率下降策略: ' + str(self.args.lr_scheduler),
            '可训练参数量: ' + str(self.param_info['可训练参数量']),
            '总参数量: ' + str(self.param_info['总参数量']),
            '可训练层数: ' + str(trainable_layers),
            '峰值显存 (allocated): ' + str(round(self.max_peak_alloc, 3)) + ' GB',
            '峰值显存 (reserved): ' + str(round(self.max_peak_reserved, 3)) + ' GB',
            '==============================',
        ]
        record_path = os.path.join(self.saver.directory, 'record.txt')
        with open(record_path, mode='w', encoding='gbk') as record_f:
            record_f.write('\n'.join(lines) + '\n')
        print('训练记录已写入：', record_path)

    def _params_df(self):
        rows = []
        for _k, _v in self.param_info.items():
            rows.append({'参数名': _k, '值': _v})
        for _k, _v in vars(self.args).items():
            rows.append({'参数名': _k, '值': _v})
        return pd.DataFrame(rows)

    def _write_excel(self, path, records_df):
        with pd.ExcelWriter(path, engine='openpyxl') as writer:
            records_df.to_excel(writer, sheet_name='Sheet1', index=False)
            self._params_df().to_excel(writer, sheet_name='sheet2', index=False)

    def training(self, epoch):
        if self.args.cuda:
            torch.cuda.reset_peak_memory_stats()
        train_loss = 0.0
        self.model.train()
        tbar = tqdm(self.train_loader)
        num_img_tr = len(self.train_loader)
        for i, sample in enumerate(tbar):
            image, target = sample['image'], sample['label']
            #print(target.shape)
            #target = target[ :, :, :,0]
            #print(target.shape)
            if self.args.cuda:
                image, target = image.cuda(), target.cuda()
            self.scheduler(self.optimizer, i, epoch, self.best_pred)
            self.optimizer.zero_grad()        #在反向传播之前，清零梯度。这是必要的步骤，因为PyTorch默认会累积梯度
            output = self.model(image)    #将图像输入模型进行前向传播，得到模型的输出。
            #print(output.shape)
            # target = target.permute(0, 3, 1, 2)
            #print(target.shape)

            loss = self.criterion(output, target)
            loss.backward()
            self.optimizer.step()
            if self.args.cuda:
                peak_alloc = torch.cuda.max_memory_allocated() / 1024 ** 3
                peak_reserved = torch.cuda.max_memory_reserved() / 1024 ** 3
                self.max_peak_alloc = max(self.max_peak_alloc, peak_alloc)
                self.max_peak_reserved = max(self.max_peak_reserved, peak_reserved)
            train_loss += loss.item()
            tbar.set_description('Train loss: %.3f' % (train_loss / (i + 1)))
            pred = output.data.cpu().numpy()
            target = target.cpu().numpy()
            pred = np.argmax(pred, axis=1)
            # Add batchbatch sample into evaluator
            self.evaluator.add_batch(target, pred)
            Acc = self.evaluator.Pixel_Accuracy()
            Acc_class = self.evaluator.Pixel_Accuracy_Class()
            train_mIOU = self.evaluator.Mean_Intersection_over_Union()
            FWIoU = self.evaluator.Frequency_Weighted_Intersection_over_Union()
            mDice = self.evaluator.Dice_coefficient()
            # self.writer.add_scalar('train/total_loss_iter', loss.item(), i + num_img_tr * epoch)  #num_img_tr为训练集图片数目
            # Show 10 * 3 inference results each epoch
            # if i % (num_img_tr // 10) == 0:
            # global_step = i + num_img_tr * epoch
            # self.summary.visualize_image(self.writer, self.args.dataset, image, target, output, global_step)
        # self.writer.add_scalar('train/total_loss_epoch', train_loss, epoch)
        # tag(string)数据标识符; scalar_value(float/string/blobname)要保存的数值;global_step(int)全局步值;walltime(float)可选参数，记录发生的时间，默认为 time.time()
        #######################################################################


        with LogWriter(logdir=self.args.logdir_train) as logw:
            logw.add_scalar(tag='loss', step=epoch, value=train_loss)
            logw.add_scalar(tag='train_mIOU', step=epoch, value=train_mIOU)
            logw.add_scalar(tag='fwIOU', step=epoch, value=FWIoU)
            logw.add_scalar(tag='Acc', step=epoch, value=Acc)
            logw.add_scalar(tag='Acc_class', step=epoch, value=Acc_class)
            logw.add_scalar(tag='mDice', step=epoch, value=mDice)


        # tag(string)记录指标的标志，如train/loss,不能含%；value(float)要记录的数值；step(int)记录的步数；walltime(int)记录数据的时间戳，默认为当前时间戳）
        # https://github.com/PaddlePaddle/VisualDL/blob/develop/docs/components/README_CN.md
        #######################################################################
        # print('[Epoch: %d, numImages: %5d]' % (epoch, i * self.args.batch_size + image.data.shape[0]))
        #print('[Epoch: %d]' % (epoch))
        #print('Train_Loss: %.3f' % train_loss)
        #loss_save = 'D:/HSQ/dataset_two-2/vocsft/vocsft3/sftTrain_loss.txt'  # 修改为自己的路径




        now = time.time()
        epoch_sec = (now - self._last_epoch_time) if self._last_epoch_time is not None else (now - self.train_start_time)
        self._last_epoch_time = now
        cum_min = (now - self.train_start_time) / 60.0
        record = {
            'Epoch': epoch,
            'Train Loss': train_loss,
            'FWIOU': FWIoU,
            'Train mIOU': train_mIOU,
            'Accuracy': Acc,
            'Acc_class': Acc_class,
            'Dice': mDice,
            '累计训练时间(分钟)': cum_min,
            '本epoch用时(秒)': epoch_sec,
        }
        if self.args.cuda:
            record['本epoch峰值(alloc,GB)'] = peak_alloc
            record['本epoch峰值(reserved,GB)'] = peak_reserved
            record['全局峰值(alloc,GB)'] = self.max_peak_alloc
            record['全局峰值(reserved,GB)'] = self.max_peak_reserved
            print('[Epoch: %d] 本epoch峰值显存(alloc): %.3f GB, 全局峰值(alloc): %.3f GB, 全局峰值(reserved): %.3f GB' %
                  (epoch, peak_alloc, self.max_peak_alloc, self.max_peak_reserved))
        self.train_records.append(record)
        self._write_excel(os.path.join(self.saver.experiment_dir, 'SLGTrain_loss.xlsx'),
                          pd.DataFrame(self.train_records))
        self._write_record()

        if self.args.checkpoint_interval is not None and (epoch + 1) % self.args.checkpoint_interval == 0:
            self.saver.save_checkpoint({
                'epoch': epoch + 1,
                'state_dict': self.model.module.state_dict() if self.args.cuda else self.model.state_dict(),
                'optimizer': self.optimizer.state_dict(),
                'best_pred': self.best_pred,
                'val_loss': getattr(self, 'val_loss', None),
            }, filename='checkpoint_epoch{}.pth.tar'.format(epoch + 1))
            print('[Epoch: %d] 已按间隔保存checkpoint: checkpoint_epoch%d.pth.tar' % (epoch, epoch + 1))

        # 保存loss的excel
        train_losses_df = pd.DataFrame(columns=['Epoch', 'Train Loss',  'Train iou'])  # 在训练循环前创建一个空的DataFrame来存储训练损失
        train_losses_df = train_losses_df.append({'Epoch': epoch, 'Train Loss': train_loss, 'Train iou': train_mIOU, 'Train Acc': Acc, 'Train Acc_class': Acc_class, 'Train Dice coefficient': mDice},  ignore_index=True)
        train_losses_df.to_excel(
            os.path.join(self.saver.experiment_dir, ('b' + str(self.args.batch_size) + 'l' + str(self.learningrate) + str(self.args.loss_type) + 'loss-train.xlsx')))





        # https://blog.csdn.net/windblow233/article/details/108741418
        #######################################################################


    def validation(self, epoch):
        model = Unet(n_channels=3, n_classes=self.args.num_classes)
        self.model.eval()
        self.evaluator.reset()
        tbar = tqdm(self.val_loader, desc='\r')
        val_loss = 0.0
        # 运用earlystopping
        # patience = 20
        # early_stopping = EarlyStopping(patience, verbose=True)
        #####################################################################
        for i, sample in enumerate(tbar):
            image, target = sample['image'], sample['label']
            if self.args.cuda:
                image, target = image.cuda(), target.cuda()
            with torch.no_grad():      #暂时禁用梯度计算。在推理阶段，不需要进行梯度计算，因此禁用梯度可以减少内存消耗并加速计算。
                output = self.model(image)         #将图像输入到模型中进行预测，并将输出赋值给output变量。self.model是已经训练好的模型。
            loss = self.criterion(output, target)
            val_loss += loss.item()
            tbar.set_description('Test loss: %.3f' % (val_loss / (i + 1)))
            pred = output.data.cpu().numpy()
            target = target.cpu().numpy()
            pred = np.argmax(pred, axis=1)
            # Add batch sample into evaluator
            self.evaluator.add_batch(target, pred)
            Acc = self.evaluator.Pixel_Accuracy()
            Acc_class = self.evaluator.Pixel_Accuracy_Class()
            val_mIOU = self.evaluator.Mean_Intersection_over_Union()
            FWIoU = self.evaluator.Frequency_Weighted_Intersection_over_Union()
            mDice = self.evaluator.Dice_coefficient()


            # early_stopping needs the validation loss to check if it has decresed,
            # and if it has, it will make a checkpoint of the current model
            # early_stopping(val_loss, model)
            # if early_stopping.early_stop:
            #     #print("Early stopping")
            #     break
            # ###################################################################################



        # Fast val during the training
        self.writer.add_scalar('val/total_loss_epoch', val_loss, epoch)
        with LogWriter(logdir=self.args.logdir_val) as logw:
            logw.add_scalar(tag='loss', step=epoch, value=val_loss)
            logw.add_scalar(tag='val_mIOU', step=epoch, value=val_mIOU)
            logw.add_scalar(tag='fwIOU', step=epoch, value=FWIoU)
            logw.add_scalar(tag='Acc', step=epoch, value=Acc)
            logw.add_scalar(tag='Acc_class', step=epoch, value=Acc_class)
            logw.add_scalar(tag='mDice', step=epoch, value=mDice)


        # self.writer.add_scalar('val/val_mIOU', val_mIOU, epoch)
        # self.writer.add_scalar('val/fwIoU', FWIoU, epoch)
        # self.writer.add_scalar('val/Acc', Acc, epoch)
        # self.writer.add_scalar('val/Acc_class', Acc_class, epoch)
        new_pred = val_mIOU
        #new_pred = Acc_class
        if new_pred > self.best_pred:
            self.best_pred = new_pred
            self.val_loss = val_loss
            self.saver.save_bestmodel({
                'epoch': epoch + 1,
                'state_dict': self.model.module.state_dict(),
                'optimizer': self.optimizer.state_dict(),
                'best_pred': self.best_pred,
                'val_loss': self.val_loss                                 ###20230524改，根据验证损失最小值保留模型
            }, filename='bestcheckpoint.pth.tar')

        # save the latest model checkpoint
        else:
            self.val_loss = val_loss
            self.saver.save_checkpoint({
                    'epoch': epoch + 1,
                    'state_dict': self.model.module.state_dict(),
                    'optimizer': self.optimizer.state_dict(),
                    'best_pred': self.best_pred,
                    'val_loss': self.val_loss                             ###20230524改，根据验证损失最小值保留模型
                }, filename='latestcheckpoint.pth.tar')


        #print('Validation:')
        #print('[Epoch: %d, numImages: %5d]' % (epoch, i * self.args.batch_size + image.data.shape[0]))
        #print('[Epoch: %d]' % (epoch))
        #print("Acc:{}, Acc_class:{}, val_mIOU:{}, fwIoU: {}, : mDice {}".format(Acc, Acc_class, val_mIOU, FWIoU, mDice))
        # print('Loss: %.3f' % val_loss)
        #print('Val_Loss: %.3f' % val_loss)
        #loss_save = 'B:/code/U-Net-pytorch-SLG/SLGVal_loss.txt'  # 修改为自己的路径



        now = time.time()
        val_record = {
            'Epoch': epoch,
            'Val Loss': val_loss,
            'FWIOU': FWIoU,
            'Val mIOU': val_mIOU,
            'Accuracy': Acc,
            'Acc_class': Acc_class,
            'Dice': mDice,
            '累计训练时间(分钟)': (now - self.train_start_time) / 60.0,
        }
        self.val_records.append(val_record)
        self._write_excel(os.path.join(self.saver.experiment_dir, 'SLGVal_loss.xlsx'),
                          pd.DataFrame(self.val_records))

        # 保存loss的excel
        val_losses_df = pd.DataFrame(columns=['Epoch', 'Val Loss',  'Val iou'])  # 在训练循环前创建一个空的DataFrame来存储训练损失
        val_losses_df = val_losses_df.append({'Epoch': epoch, 'Val Loss': val_loss, 'Val iou': val_mIOU, 'Val Acc': Acc, 'Val Acc_class': Acc_class, 'Val Dice coefficient': mDice},  ignore_index=True)
        val_losses_df.to_excel(
            os.path.join(self.saver.experiment_dir, ('b' + str(self.args.batch_size) + 'l' + str(self.learningrate) + str(self.args.loss_type) + 'loss-val.xlsx')))

    # 将epoch和对应的训练损失添加到DataFrame中
    #     val_losses_df = pd.DataFrame(columns=['Epoch',  'Validation Loss', 'Validation iou'])  # 在训练循环前创建一个空的DataFrame来存储训练损失
    #     val_losses_df = val_losses_df.append({'Epoch': epoch, 'Validation Loss': val_loss, 'Validation iou': val_mIOU}, ignore_index=True)
    #     val_train_losses_df.to_excel(
    #         os.path.join(model_save_path, ('b' + str(args.batch_size) + 'l' + str(self.learningrate) + 'vallosses.xlsx')))

    def load_checkpoint(model, optimizer, checkpoint_path):
        checkpoint = torch.load(checkpoint_path)
        model.load_state_dict(checkpoint['model_state_dict'])
        optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
        epoch = checkpoint['epoch']
        loss = checkpoint['loss']
        return model, optimizer, epoch, loss

def find_latest_checkpoint(run_dir, dataset, checkname):
    pattern = os.path.join(run_dir, dataset, checkname, 'experiment*/latestcheckpoint.pth.tar')
    matches = glob.glob(pattern)
    if not matches:
        return None

    def _exp_id(path):
        name = os.path.basename(os.path.dirname(path))
        parts = name.split('_')
        try:
            return int(parts[-1]) if len(parts) > 1 else 0
        except ValueError:
            return 0

    return sorted(matches, key=_exp_id)[-1]


def main():
    parser = argparse.ArgumentParser(description="PyTorch Unet Training")
    parser.add_argument('--dataset', type=str, default='pascal',
                        choices=['pascal', 'coco', 'cityscapes'],
                        help='dataset name (default: pascal)')
    parser.add_argument('--workers', type=int, default=0,                #https://blog.csdn.net/u010440456/article/details/119187943。20230523由4改为0.
                        metavar='N', help='dataloader threads')

    parser.add_argument('--base-size', type=int, default=512,
                        help='base image size')
    parser.add_argument('--crop-size', type=int, default=512,
                        help='crop image size')
    parser.add_argument('--loss-type', type=str, default='dicece_bce',
                        choices=['ce', 'focal', 'dicece', 'bce', 'dicece_bce'],
                        help='loss func type (default: dicece_bce)')
    # training hyper params
    parser.add_argument('--epochs', type=int, default=None, metavar='N',
                        help='number of epochs to train (default: auto)')
    parser.add_argument('--start_epoch', type=int, default=0,
                        metavar='N', help='start epochs (default:0)')
    parser.add_argument('--batch-size', type=int, default=None,
                        metavar='N', help='input batch size for \
                                training (default: auto)')
    parser.add_argument('--test-batch-size', type=int, default=None,
                        metavar='N', help='input batch size for \
                                testing (default: auto)')
    parser.add_argument('--use-balanced-weights', action='store_true', default=False,
                        help='whether to use balanced weights (default: False)')
    # optimizer params
    parser.add_argument('--lr', type=float, default=0.05, metavar='LR',
                        help='初始学习率 (default: 0.1)')
    parser.add_argument('--lr-scheduler', type=str, default='poly',
                        choices=['poly', 'step', 'cos', 'elr'],
                        help='lr scheduler mode: (default: poly)')
    parser.add_argument('--momentum', type=float, default=0.9,
                        metavar='M', help='momentum (default: 0.9)')
    parser.add_argument('--weight-decay', type=float, default=1e-4,
                        metavar='M', help='w-decay (default: 4e-5)')
    parser.add_argument('--nesterov', action='store_true', default=False,
                        help='whether use nesterov (default: False)')
    # cuda, seed and logging
    parser.add_argument('--no-cuda', action='store_true', default=False,
                        help='disables CUDA training')
    parser.add_argument('--gpu-ids', type=str, default='0',  # default='0',表示指定显卡为默认显卡，若为多显卡可设置为default='0,1,2.......'
                        help='use which gpu to train, must be a \
                        comma-separated list of integers only (default=0)')
    parser.add_argument('--seed', type=int, default=1, metavar='S',
                        help='random seed (default: 1)')
    # checking point
    parser.add_argument('--resume', action='store_true', default=False,
                        help='是否从checkpoint继续训练 (default: False)')
    parser.add_argument('--checkname', type=str, default=None,
                        help='set the checkpoint name')
    # finetuning pre-trained models
    parser.add_argument('--ft', action='store_true', default=False,
                        help='finetuning on a different dataset')                         #迁移学习
    # evaluation option
    parser.add_argument('--eval-interval', type=int, default=1,
                        help='evaluuation interval (default: 1)')
    parser.add_argument('--no-val', action='store_true', default=False,
                        help='skip validation during training')
    # path / logging config
    parser.add_argument('--project-root', type=str, default=None,
                        help='项目根目录，默认取train.py所在目录')
    parser.add_argument('--run-dir', type=str, default=None,
                        help='输出根目录(模型与日志)，默认<project-root>/run')
    parser.add_argument('--data-root', type=str, default='A:/B_diskexpand/Code/GrMflakes/data/SEM',
                        help='数据集根目录，覆盖mypath.py中的路径')
    parser.add_argument('--num-classes', type=int, default=2,
                        help='分类数 (default: 2)')
    parser.add_argument('--logdir-train', type=str, default=None,
                        help='VisualDL训练日志目录，默认自动推导')
    parser.add_argument('--logdir-val', type=str, default=None,
                        help='VisualDL验证日志目录，默认自动推导')
    parser.add_argument('--check', type=str, default=None,
                        help='断点续训路径，默认自动查找最新experiment')
    parser.add_argument('--checkpoint-interval', type=int, default=20,
                        help='每隔N个epoch保存一次checkpoint (default: None，不保存)')

    args = parser.parse_args()
    args.cuda = not args.no_cuda and torch.cuda.is_available()
    if args.cuda:
        try:
            args.gpu_ids = [int(s) for s in args.gpu_ids.split(',')]
        except ValueError:
            raise ValueError('Argument --gpu_ids must be a comma-separated list of integers only')

    # default settings for epochs, batch_size and lr
    if args.epochs is None:
        epoches = {
            'coco': 30,
            'cityscapes': 200,
            'pascal': 1000,
        }
        args.epochs = epoches[args.dataset.lower()]

    if args.batch_size is None:
        #args.batch_size = 2 * len(args.gpu_ids)
        args.batch_size = 6
    if args.test_batch_size is None:
        args.test_batch_size = args.batch_size

    if args.lr is None:
        args.lr = 0.1    #指定为初始学习率；如需自动缩放公式，可改用 lrs[dataset]/(2*len(gpu_ids))*batch_size
    if args.checkname is None:
        args.checkname = 'Unet'
    if args.project_root is None:
        args.project_root = os.path.dirname(os.path.abspath(__file__))
    if args.run_dir is None:
        args.run_dir = os.path.join(args.project_root, 'run')
    if args.logdir_train is None:
        args.logdir_train = os.path.join(args.run_dir, args.dataset, args.checkname, 'log', 'scalar_testSLG')
    if args.logdir_val is None:
        args.logdir_val = os.path.join(args.run_dir, args.dataset, args.checkname, 'log', 'scalar_testSLG')
    for _logdir in (args.logdir_train, args.logdir_val):
        if not os.path.isdir(_logdir):
            os.makedirs(_logdir)
    #print(args)
    torch.manual_seed(args.seed)
    trainer = Trainer(args)
    print('Starting Epoch:', trainer.args.start_epoch)
    print('Total Epoches:', trainer.args.epochs)
    for epoch in range(trainer.args.start_epoch, trainer.args.epochs):
        trainer.training(epoch)
        if not trainer.args.no_val and epoch % args.eval_interval == (args.eval_interval - 1):
            trainer.validation(epoch)
    trainer._write_record()
    trainer.writer.close()


if __name__ == "__main__":
    CUDA_LAUNCH_BLOCKING = 1

    main()