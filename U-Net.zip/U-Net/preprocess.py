from PIL import Image
import numpy as np
import math
import cv2
import numpy as np
import matplotlib.pyplot as plt
import os

def preprocess(image, delta, boundary=255):
    image_array = np.asarray(image)
    flattened_image_array = image_array.flatten()
    intensity_unique, intensity_count = np.unique(np.sort(flattened_image_array), return_counts=True)
    pdf = intensity_count / np.sum(intensity_count)                                                           #公式2，计算图像的概率密度函数pdf（l）
    ks = find_cut_ks(pdf, intensity_unique)                                                                   #返回用于分割图片的三个k

    sub_intensity_unique = cut_array(intensity_unique, ks)
    sub_intensity_count = cut_array(intensity_count, ks)
    sub_pdf = [sub_intensity_count[i] / np.sum(sub_intensity_count[i]) for i in range(len(sub_intensity_count))]

    v_convert_pdf = np.vectorize(convert_pdf)
    new_sub_pdf = [v_convert_pdf(i) for i in sub_pdf]
    new_sub_cdf = [np.cumsum(i) for i in new_sub_pdf]

    equalized = [equalization(new_sub_cdf[i], sub_intensity_unique[i]) for i in range(len(new_sub_cdf))]      #every segment is equalized independently
    equalized_intensity_unique = np.concatenate(equalized, boundary)

    normalized_intensity_unique = normalization(equalized_intensity_unique)                                   #normalization of intensity levels
    processed_intensity_unique = normalized_intensity_unique * delta + intensity_unique * (1 - delta)         #公式16，PRCimg=δ*INTimg+(1-δ)*INPimg
    result = apply_mapping(image_array, intensity_unique, processed_intensity_unique)
    return result

def np_cut_pdf(pdf, intensity):
    max_k = pdf.size - 1
    max_sigma = 0
    max_sigma_k = 0
    for k in range(1, max_k):
        omega_l = pdf[:k].sum()                                             #公式3，ω_l为0-k段直方图的概率密度和
        omega_r = pdf[k:].sum()                                             #公式3，ω_r为l=k+1 → lmax段直方图的概率密度和
        mu_l = np.dot(pdf[:k], intensity[:k]) / omega_l                     #公式4，μ_l为每部分的平均值
        mu_r = np.dot(pdf[k:], intensity[k:]) / omega_r                     #公式4
        mu = mu_l * omega_l + mu_r * omega_r                                #公式5
        mu_delta_l = mu_l - mu                                              #μ_△l=μ_l-μ
        mu_delta_r = mu_r - mu                                              #μ_△r=μ_r-μ
        sigma = omega_l * (mu_delta_l ** 2) + omega_r * (mu_delta_r ** 2)   #公式6，sigma即文中σ^2
        if sigma > max_sigma:
            max_sigma = sigma
            max_sigma_k = k
    return max_sigma_k                                                      #公式7，max_sigma_k即max(σ^2)

def find_cut_ks(pdf, intensity):
    k_2 = np_cut_pdf(pdf, intensity)                                        #公式7，k_2即最优阈值kopt
    pdf_l = pdf[:k_2]                                                       #pdf_l为最优阈值之前子直方图的概率。
    pdf_r = pdf[k_2:]                                                       #pdf_r为最优阈值之后子直方图的概率。
    intensity_l = intensity[:k_2]                                           #最优阈值之前的图像强度总和
    intensity_r = intensity[k_2:]
    k_1 = np_cut_pdf(pdf_l, intensity_l)                                    #以最优阈值为界再分为四个子直方图
    k_3 = np_cut_pdf(pdf_r, intensity_r)
    ks = [k_1, k_2, k_3 + k_2]                                              #公式9，所有的子直方图构成ks列表
    return ks

def cut_array(arr, ks):
    results = []
    for i in range(len(ks) + 1):
        if i == 0:
            results.append(arr[:ks[i]])
        elif i == len(ks):
            results.append(arr[ks[i - 1]:])
        else:
            results.append(arr[ks[i - 1]:ks[i]])
    return results

def convert_pdf(pdf):
    return (math.exp(pdf) - math.exp(-pdf)) / (math.exp(pdf) + math.exp(-pdf))      #公式11

def equalization(cdf, intensity):
    max_i = np.max(intensity)
    min_i = np.min(intensity)
    return cdf * (max_i - min_i) + min_i                                            #公式13

def normalization(equalized_intensity, boundary=255):
    min_e = np.min(equalized_intensity)
    max_e = np.max(equalized_intensity)
    normalized_intensity_unique = np.multiply(np.subtract(equalized_intensity, min_e), #即求T(l)
                                              boundary / (max_e - min_e))           #公式15，equalized_intensity即L。 max_e, min_e即lmax, lmin
    return normalized_intensity_unique

def apply_mapping(arr, i, o):
    idx = np.searchsorted(i, arr.ravel()).reshape(arr.shape)
    idx[idx==len(i)] = 0
    mask = i[idx] == arr
    out = np.where(mask, o[idx], 0)
    return out

if __name__=='__main__':
    #path="D:\\HSQ\\dataset_two-2\\voc2012\\JPEGImages-origin\\"
    path = "B:/code/U-Net-pytorch-SLG/data/JPEGImages/"
    dirs = os.listdir(path)
    print(dirs)  ##打印文件下图像的名称
    for i in range(0, len(dirs)):  #i是图像的顺序
        img2 = cv2.imread(path+dirs[i], 0)
        print(img2)
        delta = 0.5
        result1 = preprocess(img2, delta, boundary=255)
        #cv2.imwrite("D:/HSQ/dataset_two-2/vocsft/vocsft3/JPEGImages/histogram/" + str(dirs[i]) + "-" + str(delta)+".jpg", result1)
        cv2.imwrite(
            "B:/code/U-Net-pytorch-SLG/data/histogram/" + str(dirs[i]) + "-" + str(delta) + ".jpg",
            result1)

    print("ok!!!!!!")

#if __name__ == '__main__':
    # 读取原始图像
    #img = cv2.imread('D:/HSQ/dataset_two-2/vocsft/vocsft3/JPEGImages/9-5.jpg', cv2.IMREAD_GRAYSCALE)
    #new_img = preprocess(img, 0.3, boundary=255)
    #plt.imshow(new_img, cmap=plt.cm.gray)
#https: // blog.csdn.net / weixin_41059269 / article / details / 97028518

