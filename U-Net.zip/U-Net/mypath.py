class Path(object):
    @staticmethod
    def db_root_dir(dataset):
        if dataset == 'pascal':

            # return 'B:/code/U-Net-pytorch-SLG/data/'
            return 'A:/B_diskexpand/Code/GrMflakes/data/SEM'   # 改为自己的路径，包含了ImageSets、JPEGImages和SegmentationClass这3个文件夹
        elif dataset == 'cityscapes':
            return '/path/to/datasets/cityscapes/'     # foler that contains leftImg8bit/
        elif dataset == 'coco':
            return '/path/to/datasets/coco/'
        else:
            print('Dataset {} not available.'.format(dataset))
            raise NotImplementedError
