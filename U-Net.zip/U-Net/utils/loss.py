import torch
import torch.nn as nn
import torch.nn.functional as F

class SegmentationLosses(object):
    #def __init__(self, weight=None, size_average=True, batch_average=True, ignore_index=255, cuda=False):
    def __init__(self, weight=None, reduction='mean', batch_average=True, ignore_index=255, cuda=False):
        self.ignore_index = ignore_index
        self.weight = weight
        self.reduction = reduction
        self.batch_average = batch_average
        self.cuda = cuda

    #def build_loss(self, mode='ce'):
    def build_loss(self, mode='focal'):

        """Choices: ['ce', 'focal', 'dicece', 'bce', 'dicece_bce']"""
        if mode == 'ce':
            return self.CrossEntropyLoss
        elif mode == 'focal':
            return self.FocalLoss
        elif mode == 'dicece':
            return self.DiceCELoss
        elif mode == 'bce':
            return self.BCELoss
        elif mode == 'dicece_bce':
            return self.DiceCE_BCELoss
        else:
            raise NotImplementedError

    def CrossEntropyLoss(self, logit: object, target: object) -> object:
        n, c, h, w = logit.size()
        criterion = nn.CrossEntropyLoss(weight=self.weight, ignore_index=self.ignore_index,
                                        reduction=self.reduction)
        if self.cuda:
            criterion = criterion.cuda()

        loss = criterion(logit, target.long())

        if self.batch_average:
            loss /= n
        return loss

    def FocalLoss(self, logit, target, gamma=2, alpha=0.5):
        n, c, h, w = logit.size()
        criterion = nn.CrossEntropyLoss(weight=self.weight, ignore_index=self.ignore_index,
                                        reduction=self.reduction)
        if self.cuda:
            criterion = criterion.cuda()

        logpt = -criterion(logit, target.long())
        pt = torch.exp(logpt)
        if alpha is not None:
            logpt *= alpha
        loss = -((1 - pt) ** gamma) * logpt

        if self.batch_average:
            loss /= n

        return loss

    def DiceLoss(self, logit, target, eps=1e-6):
        n, c, h, w = logit.size()
        probs = torch.softmax(logit, dim=1)
        target_valid = target.clamp(0, c - 1)
        target_onehot = F.one_hot(target_valid.long(), num_classes=c).permute(0, 3, 1, 2).float()
        intersection = (probs * target_onehot).sum(dim=(2, 3))
        union = probs.sum(dim=(2, 3)) + target_onehot.sum(dim=(2, 3))
        dice = (2 * intersection + eps) / (union + eps)
        loss = 1 - dice.mean()
        return loss

    def _CrossEntropyComponent(self, logit, target):
        criterion = nn.CrossEntropyLoss(weight=self.weight, ignore_index=self.ignore_index,
                                        reduction=self.reduction)
        if self.cuda:
            criterion = criterion.cuda()
        return criterion(logit, target.long())

    def BCELoss(self, logit, target):
        n, c, h, w = logit.size()
        assert c == 2, 'BCE loss 仅适用于二分类 (num_classes=2)，当前为 {} 类'.format(c)
        valid = target != self.ignore_index
        target_bin = torch.where(valid, (target == 1).float(), torch.zeros_like(target, dtype=torch.float))
        logit_fg = logit[:, 1]
        criterion = nn.BCEWithLogitsLoss(reduction='none')
        if self.cuda:
            criterion = criterion.cuda()
        loss = criterion(logit_fg, target_bin) * valid.float()
        if valid.any():
            loss = loss.sum() / valid.sum().float()
        else:
            loss = loss.sum()
        return loss

    def DiceCELoss(self, logit, target):
        return self.DiceLoss(logit, target) + self._CrossEntropyComponent(logit, target)

    def DiceCE_BCELoss(self, logit, target):
        return (self.DiceLoss(logit, target) + self._CrossEntropyComponent(logit, target)
                + self.BCELoss(logit, target))

if __name__ == "__main__":
    loss = SegmentationLosses(cuda=True)
    a = torch.rand(1, 3, 7, 7).cuda()
    b = torch.rand(1, 7, 7).cuda()
    print(loss.CrossEntropyLoss(a, b).item())
    print(loss.FocalLoss(a, b, gamma=0, alpha=None).item())
    print(loss.FocalLoss(a, b, gamma=2, alpha=0.5).item())