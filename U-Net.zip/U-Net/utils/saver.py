import os
import shutil
import torch
from collections import OrderedDict
import glob


class Saver(object):

    def __init__(self, args):

        self.args = args
        #self.min_valloss = 0.058
        self.directory = os.path.join(getattr(args, 'run_dir', 'run'), args.dataset, args.checkname)
        self.runs = sorted(glob.glob(os.path.join(self.directory, 'experiment_*')))
        run_id = int(self.runs[-1].split('_')[-1]) + 1 if self.runs else 0
        self.experiment_dir = os.path.join(self.directory, 'experiment_{}'.format(str(run_id)))
        self.previous_valloss = [1.0]
        self.previous_mIOU = [0.0]

        if not os.path.exists(self.experiment_dir):
            os.makedirs(self.experiment_dir)

    # def save_checkpoint(self, state, is_best, filename= 'checkpoint.pth.tar'):
    def save_checkpoint(self, state, filename):
        """Saves checkpoint to disk"""
        filename = os.path.join(self.experiment_dir, filename)
        torch.save(state, filename)

        # if is_best:
        #     best_pred = state['best_pred']
        #     with open(os.path.join(self.experiment_dir, 'best_pred.txt'), 'w') as f:
        #         f.write(str(best_pred))
        #     if self.runs:
        #         previous_miou = [0.0]
        #         for run in self.runs:
        #             run_id = run.split('_')[-1]
        #             path = os.path.join(self.directory, 'experiment_{}'.format(str(run_id)), 'best_pred.txt')
        #             if os.path.exists(path):
        #                 with open(path, 'r') as f:
        #                     miou = float(f.readline())
        #                     previous_miou.append(miou)           #previous_miou为所有miou的集合

        best_pred = state['best_pred']
        with open(os.path.join(self.experiment_dir, 'best_pred.txt'), 'w') as f:
            f.write(str(best_pred))
        if self.runs:
            previous_miou = [0.0]
            for run in self.runs:
                run_id = run.split('_')[-1]
                path = os.path.join(self.directory, 'experiment_{}'.format(str(run_id)), 'best_pred.txt')
                if os.path.exists(path):
                    with open(path, 'r') as f:
                        miou = float(f.readline())
                        previous_miou.append(miou)           #previous_miou为所有miou的集合
                    # else:
                    #     continue

                #     shutil.copyfile(filename, os.path.join(self.directory, 'model_best.pth.tar'))
                    #torch.save(state, os.path.join(self.experiment_dir, 'model_best.pth.tar'))
            #else:
                #shutil.copyfile(filename, os.path.join(self.directory, 'model_best.pth.tar'))
                #shutil.copyfile(filename, os.path.join(self.experiment_dir, 'model_best.pth.tar'))

    def save_bestmodel(self, state, filename):
        """Saves checkpoint to disk"""
        filename = os.path.join(self.experiment_dir, filename)
        torch.save(state, filename)
        best_pred = state['best_pred']
        with open(os.path.join(self.experiment_dir, 'best_pred.txt'), 'w') as f:
            f.write(str(best_pred))
        if self.runs:
            previous_miou = [0.0]
            for run in self.runs:
                run_id = run.split('_')[-1]
                path = os.path.join(self.directory, 'experiment_{}'.format(str(run_id)), 'best_pred.txt')
                if os.path.exists(path):
                    with open(path, 'r') as f:
                        miou = float(f.readline())
                        previous_miou.append(miou)           #previous_miou为所有miou的集合



    # def save_bestmodel(self, state, best_prediction, pre_miou):
    #
    #     max_miou = max(pre_miou)
    #     test_loss = state['test_loss']
    #     mIOU=state[' ']
    #     self.previous_valloss.append(test_loss)
    #     self.previous_mIOU.append(miou)
    #     min_valloss = min(self.previous_valloss)
    #     lossfurther = self.previous_valloss[-2]
    #
    #     print("所有loss为：", self.previous_valloss)
    #     epoch = state['epoch']
    #     if best_prediction >= max_miou:  # 如果mIOU创新高
    #         #print("验证损失为：", test_loss)
    #         #print("损失值需低于：", self.min_valloss)
    #         print("所有的最高预测值为：", self.previous_miou)
    #         print("\n miou不降低；")
    #         if test_loss < lossfurther:
    #             print("本轮损失", test_loss)
    #             print("，低于前一轮损失", lossfurther)
    #             if test_loss < 2*min_valloss:
    #                 print("；并且低于2倍min_valloss时保存模型")
    #                 # self.min_valloss = test_loss
    #                 # print("\n最小验证损失值为：", self.min_valloss)
    #                 print("\n保存的最好模型训练轮次为：", epoch-1)
    #                 torch.save(state, os.path.join(self.experiment_dir, 'model_best.pth.tar'))





    def save_experiment_config(self):
        logfile = os.path.join(self.experiment_dir, 'parameters.txt')
        log_file = open(logfile, 'w')
        p = OrderedDict()
        p['datset'] = self.args.dataset
        p['lr'] = self.args.lr
        p['lr_scheduler'] = self.args.lr_scheduler
        p['loss_type'] = self.args.loss_type
        p['epoch'] = self.args.epochs
        p['base_size'] = self.args.base_size
        p['crop_size'] = self.args.crop_size
        p['batchsize'] = self.args.batch_size
        p['numworkers'] = self.args.workers
        p['classes'] = self.args.num_classes


        for key, val in p.items():
            log_file.write(key + ':' + str(val) + '\n')
        log_file.close()